package com.example.v2.model;

public record GradeLevel(Long id, String name, Long parentId) {}
