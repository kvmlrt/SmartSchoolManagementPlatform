package com.example.v2.model;

public record ClassInfo(Long id, String name, Long gradeLevelId) {}
