package com.example.v2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineEducationV2Application {
    public static void main(String[] args) {
        SpringApplication.run(OnlineEducationV2Application.class, args);
    }
}
